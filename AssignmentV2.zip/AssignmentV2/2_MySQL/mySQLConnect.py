# import mysql.connector
import mysql.connector as mysql
from creds import *

# in creds file
# dbUSer = "userName"  # root
# dbPass = "password"

# conn = mysql.connect( host="localhost", user=dbUSer, password = dbPass )
# database=""

conn = mysql.connect(host="localhost", database="sharks_final",
                     user=dbUSer, password=dbPass)
# # is connecteed reports whether the connection to MySQL server is available
if conn.is_connected():
    print("Connected to MySQL Server")
else:
    print("Not Connected to MySQL Server!!")

# prepared = return a cursor which uses the prepared statements
cursor = conn.cursor(prepared=True)

# # To create databse from python
# cursor.execute("CREATE DATABASE sharks_final")

# # display all dtabases from mysql server
# cursor.execute("SHOW DATABASES")
# # allDbs = cursor.execute("SHOW DATABASES")
# for dbs in cursor:
#     print(dbs)

# display all tables from a specific database from mysql server
# cursor.execute("SHOW TABLES")
# # allTBLS = cursor.execute("SHOW TABLES")
# for tbls in cursor:
#     print(tbls)


# display all tables from a specific database from mysql server
cursor.execute("SELECT * FROM Members")
row = cursor.fetchall()  # records fetched saved/passed in to the row varible
for record in row:
    print(record)
