SELECT *
FROM Members
WHERE date_of_birth = 2022/03/14

SELECT *
FROM Members
WHERE City = 'London'

SELECT *
FROM Members
WHERE Firstname = 'Jackson'
