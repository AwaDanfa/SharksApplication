import sqlite3 as sql  # import the sqlite3 module

# Create a connection object that represent the database you want to create and/or use  in order to ​
# use the SQLite module imported in line 1 this ​ensures that we can perform various database operations.
# ​
# connect() = connection method to creates db abd connect to it if it doed not exist
# otherwise it will just connect to and use the existing DB

conn = sql.connect("1_SQLiteDB/sharks_final.db")

# now, create a cursor object after establishing a connection in step .

# cursor() = cursor object
cursor = conn.cursor()
