from connect import *
import time

# subroutine


def searchID():
    # which field can be used to update record(s) in the Members table?
    "Use the MemberID(unique/primary key)"
    idField = input("Enter the MemberID  to search for: ")

    idmember = cursor.execute(
        f"SELECT * from Members WHERE MemberID = {idField}")
    for record in idmember:

        print(f"Member {record} found in the Members table")


if __name__ == "__main__":
    searchID()


def searchbyLastName():
    # which field can be used to update record(s) in the Members table?
    "Use the Member surname()"
    lastname = input("Enter the Member last name to search for: ")
    lastname = "'"+lastname+"'"
    mlastname = cursor.execute(
        f"SELECT * from Members WHERE Surname = {lastname}")
    for record in mlastname:

        print(f"Member {record} found in the Members table")


if __name__ == "__main__":
    searchbyLastName()
