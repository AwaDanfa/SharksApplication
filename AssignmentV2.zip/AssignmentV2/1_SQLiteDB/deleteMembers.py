from connect import *
import readMembers
import time

# subroutine


def delete():
    # which field can be used to update record(s) in the Members table?
    "Use the MemberID(unique/primary key)"
    idField = input("Enter the MemberID of the record to be deleted: ")

    cursor.execute(
        f"DELETE from songs WHERE MemberID = {idField}")
    conn.commit()

    print(f"Record {idField} deleted from the Members table")
    time.sleep(3)

    # read from the Members table
    readMembers.read()  # call the read subroutine from the readMembers python file


if __name__ == "__main__":
    delete()
