CREATE SCHEMA
`Sharks`;

USE Sharks;


CREATE TABLE Course
(
  CourseID INT NOT NULL,
  Level VARCHAR(50) NOT NULL,
  Sessions VARCHAR(50) NOT NULL,
  Instructor VARCHAR(60) NOT NULL,
  StartDate datetime NOT NULL,
  LessonTime VARCHAR(60) NOT NULL,
  PRIMARY KEY(CourseID)
);


CREATE TABLE Members
(
  MemberID INT NOT NULL,
  Firstname VARCHAR(50) NOT NULL,
  Surname VARCHAR(50) NOT NULL,
  date_of_birth DATETIME NOT NULL,
  Address VARCHAR(60) NOT NULL,
  City VARCHAR(50) NOT NULL,
  PRIMARY KEY(MemberID)
);


CREATE TABLE Lessons
(
  LessonID INT NOT NULL,
  CourseID INT NOT NULL,
  MemberID INT NOT NULL,
  PRIMARY KEY(LessonID),
  INDEX CourseID (CourseID ASC),
  CONSTRAINT CourseID
FOREIGN KEY (CourseID)
REFERENCES course (CourseID)
ON DELETE CASCADE 
ON UPDATE CASCADE,
  CONSTRAINT MemberID
FOREIGN KEY (MemberID)
REFERENCES Members (MemberID)
ON DELETE CASCADE 
ON UPDATE CASCADE
);



insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (1, 'Stage 1', 'Morning', 'Nadine', '2023-03-18', '07:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (2, 'Stage 2', 'Morning', 'Erika', '2022-05-06', '08:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (3, 'Stage 2', 'Morning', 'James', '2022-02-18', '09:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (4, 'Stage 2', 'Morning', 'Saliou', '2022-01-31', '08:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (5, 'Stage 3', 'Morning', 'Erika', '2022-09-19', '07:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (6, 'Stage 2', 'Morning', 'Saliou', '2023-01-31', '09:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (7, 'Stage 3', 'Morning', 'Nadine', '2022-06-14', '08:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (8, 'Stage 3', 'Morning', 'Nadine', '2022-04-16', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (9, 'Stage 4', 'Morning', 'Erika', '2022-12-20', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (10, 'Stage 3', 'Morning', 'Erika', '2022-07-11', '09:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (11, 'Stage 3', 'Morning', 'Saliou', '2022-05-11', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (12, 'Stage 3', 'Morning', 'Erika', '2022-09-10', '08:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (13, 'Stage 1', 'Morning', 'Saliou', '2023-03-10', '08:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (14, 'Stage 1', 'Morning', 'Saliou', '2023-01-08', '08:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (15, 'Stage 4', 'Morning', 'Saliou', '2022-02-27', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (16, 'Stage 4', 'Morning', 'Nadine', '2022-03-14', '07:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (17, 'Stage 2', 'Morning', 'Tash', '2022-11-05', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (18, 'Stage 4', 'Morning', 'Saliou', '2022-12-21', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (19, 'Stage 1', 'Morning', 'James', '2022-03-15', '08:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (20, 'Stage 3', 'Morning', 'Tash', '2022-10-19', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (21, 'Stage 4', 'Morning', 'James', '2022-07-21', '08:00');

insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (22, 'Stage 1', 'Evening', 'Tash', '2022-06-25', '17:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (23, 'Stage 3', 'Evening', 'James', '2023-01-31', '19:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (24, 'Stage 3', 'Evening', 'Tash', '2023-03-29', '18:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (25, 'Stage 4', 'Evening', 'Erika', '2022-11-02', '18:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (26, 'Stage 3', 'Evening', 'Tash', '2022-11-12', '19:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (27, 'Stage 4', 'Evening', 'Nadine', '2022-05-22', '19:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (28, 'Stage 2', 'Evening', 'James', '2022-08-05', '19:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (29, 'Stage 2', 'Evening', 'Erika', '2022-07-12', '19:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (30, 'Stage 3', 'Evening', 'Saliou', '2023-01-04', '19:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (31, 'Stage 2', 'Evening', 'Saliou', '2023-01-05', '17:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (32, 'Stage 1', 'Evening', 'Erika', '2022-12-28', '18:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (33, 'Stage 2', 'Evening', 'Erika', '2023-01-10', '18:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (34, 'Stage 4', 'Evening', 'James', '2022-12-06', '17:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (35, 'Stage 1', 'Evening', 'James', '2022-02-25', '19:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (36, 'Stage 1', 'Evening', 'James', '2023-03-23', '18:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (37, 'Stage 1', 'Evening', 'Tash', '2022-03-27', '18:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (38, 'Stage 1', 'Evening', 'Tash', '2022-08-28', '19:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (39, 'Stage 1', 'Evening', 'Tash', '2022-05-20', '18:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (40, 'Stage 3', 'Evening', 'Nadine', '2022-11-20', '18:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (41, 'Stage 2', 'Evening', 'Erika', '2023-03-18', '18:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (42, 'Stage 4', 'Evening', 'Saliou', '2022-02-24', '18:30');



insert into lessons
  (LessonID, CourseID, MemberID)
values
  (1, '4', 1);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (2, '27', 2);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (3, '23', 3);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (4, '29', 4);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (5, '16', 5);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (6, '20', 6);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (7, '42', 7);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (8, '5', 8);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (9, '31', 9);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (10, '14', 10);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (11, '37', 11);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (12, '11', 12);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (13, '36', 13);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (14, '33', 14);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (15, '40', 15);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (16, '32', 16);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (17, '21', 17);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (18, '24', 18);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (19, '12', 19);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (20, '30', 20);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (21, '8', 21);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (22, '25', 22);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (23, '3', 23);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (24, '13', 24);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (25, '19', 25);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (26, '41', 26);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (27, '10', 27);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (28, '6', 28);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (29, '2', 29);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (30, '22', 30);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (31, '9', 31);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (32, '17', 32);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (33, '38', 33);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (34, '1', 34);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (35, '18', 35);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (36, '35', 36);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (37, '34', 37);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (38, '28', 38);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (39, '26', 39);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (40, '7', 40);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (41, '15', 41);
insert into lessons
  (LessonID, CourseID, MemberID)
values
  (42, '39', 42);



insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('4', 'Arty', 'Blount', '2022/03/06', '39392 Oak Way', 'Banjar Mambalkajanan');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('39', 'Bartolemo', 'Romke', '2022/04/19', '0 Mosinee Terrace', 'Seixezelo');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('23', 'Kelci', 'Dottrell', '2022/07/30', '793 Basil Parkway', 'Póvoa de Penela');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('28', 'Lacey', 'Lindenblatt', '2022/09/30', '7 Lawn Point', 'Tinawagan');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('38', 'Jacobo', 'McRavey', '2022/06/17', '79 Burrows Terrace', 'Medveđa');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('1', 'Kerwinn', 'Daldry', '2022/10/28', '177 Alpine Court', 'Cergy-Pontoise');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('18', 'Emelen', 'Kleiser', '2023/01/04', '458 Roxbury Hill', 'Emnambithi-Ladysmith');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('35', 'Erika', 'Cleveley', '2022/03/21', '25 Truax Drive', 'Shengping');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('19', 'Winifield', 'Partener', '2022/04/13', '03008 Fordem Trail', 'Shedok');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('42', 'Bernarr', 'Minigo', '2022/06/09', '64745 Lindbergh Pass', 'Huayuan');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('40', 'Teddi', 'Paddison', '2023/01/07', '069 Bay Crossing', 'Zhatay');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('13', 'Evangelina', 'Iggo', '2022/08/29', '8720 Nova Junction', 'Sagua de Tánamo');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('30', 'Rhett', 'Blackwell', '2022/03/12', '177 Scofield Crossing', 'Sanhe');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('3', 'Parker', 'Vedenichev', '2022/08/25', '93482 Donald Terrace', 'Marfino');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('2', 'Thorin', 'Wilcocke', '2022/03/14', '2 Susan Drive', 'Paleran');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('11', 'Palmer', 'Tixier', '2022/07/14', '41272 Blue Bill Park Pass', 'Jargalant');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('41', 'Magdalena', 'Shakeshaft', '2022/07/25', '49 Hagan Alley', 'Tilburg');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('36', 'Merv', 'Proughten', '2022/08/01', '861 Maple Center', 'Nawá');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('24', 'Merry', 'Churchman', '2022/03/22', '3076 Northwestern Trail', 'Ḩakamā');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('21', 'Tris', 'Zellmer', '2022/03/02', '29 Bartillon Terrace', 'Igir-igir');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('32', 'Saw', 'Macoun', '2022/02/13', '37790 Utah Avenue', 'Durham');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('12', 'Humfried', 'Redemile', '2022/10/01', '0 Ridgeway Way', 'Umunede');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('5', 'Bart', 'Whight', '2022/08/30', '7870 Stephen Center', 'Tamiso');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('6', 'Alverta', 'Stickley', '2022/02/27', '13 Havey Center', 'Dois Vizinhos');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('29', 'Pansie', 'Staner', '2022/08/23', '65502 Manley Junction', 'Camiri');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('9', 'Madelena', 'Daveran', '2022/12/25', '8 Blaine Street', 'Malo');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('33', 'Winny', 'Paine', '2022/03/06', '49 Mifflin Point', 'Choca do Mar');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('26', 'Elyssa', 'Leah', '2022/12/06', '1 Autumn Leaf Plaza', 'Guanqian');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('10', 'Keane', 'Chalke', '2022/10/07', '5372 Prairie Rose Alley', 'Kuala Lumpur');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('25', 'Allie', 'Heaps', '2022/05/17', '23 Valley Edge Pass', 'Korsze');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('14', 'Belle', 'Beeton', '2022/12/07', '27 3rd Road', 'Iberia');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('7', 'Franciskus', 'Watkins', '2022/07/28', '069 Lukken Plaza', 'Liozon');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('8', 'Bogey', 'Neicho', '2022/07/11', '1267 Armistice Point', 'Frederiksberg');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('16', 'Boyce', 'Poxon', '2022/07/05', '6241 Anhalt Junction', 'Taipa');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('22', 'Donella', 'Vigers', '2022/02/09', '7278 Florence Center', 'Solidaridad');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('17', 'Rori', 'Winspear', '2022/02/08', '0 Artisan Point', 'Gontar');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('27', 'Donaugh', 'Boutton', '2022/05/01', '4648 Calypso Place', 'Iłowo -Osada');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('20', 'Miltie', 'Challace', '2023/01/10', '1962 3rd Park', 'Aurora');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('37', 'Der', 'Hodgin', '2022/12/27', '8 Maple Terrace', 'Girona');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('15', 'Malanie', 'Lode', '2022/06/23', '4 Sullivan Lane', 'Bouctouche');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('34', 'Jilli', 'Pluvier', '2022/06/08', '48751 Alpine Avenue', 'Luoshan');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('31', 'Jackson', 'Stiller', '2022/09/26', '9503 Raven Way', 'Rincón');

-- To display tables in a DB
SHOW TABLES;
DESC course;
EXPLAIN course;

DESC lessons;
EXPLAIN lessons;

SELECT *
FROM course;
SELECT *
FROM lessons;

-- Display all records from the course table 
SELECT *
FROM course;

DROP table course;
DROP table lessons;
DROP table members;

-- Exercices

-- A. Use the SQL AND, OR and NOT Operators in your query (The WHERE clause can be combined with AND, OR, and NOT operators)
-- 1. Where courseID is equals to a number below 5 and the first name of any of the instructors 
SELECT *
FROM course;
SELECT *
FROM course
WHERE courseID <= 5 AND Instructor = 'Nadine';

-- 2. Where courseID is equals to a number above 5 and the lesson time is in the morning or afternoon. 

SELECT *
FROM course
WHERE courseID >= 5 AND Sessions = 'Morning';

-- B. Order by the above results by:
-- 1. startDate in “course” table
SELECT *
FROM Course
ORDER BY startDate DESC;
-- 2.	 MemberID in “members” table
SELECT *
FROM Members
ORDER BY MemberID DESC;

-- C.	UPDATE the following:
-- 1.	 Members table, change the addresses of any three members.
SELECT *
FROM Members;
UPDATE Members SET Address = '10 rue Jean Moulin' WHERE MemberID = 2;
UPDATE Members SET Address = '21 Jump Street' WHERE MemberID = 5;
UPDATE Members SET Address = '90210 Beverly Hills' WHERE MemberID = 6;

-- 2.	Course table, change the startDate and lesson time for three of the sessions.
SELECT *
FROM course;
-- not working
/* UPDATE Course SET startDate = '2022-08-23'
AND lessonTime = '07:00' WHERE CourseID = 10;
UPDATE Course SET startDate = 2023-01-01
AND lessonTime = '08:00' WHERE  CourseID = 11;
UPDATE Course SET startDate = 2022-11-15
AND lessonTime = '19:00' WHERE CourseID = 12;
 */
-- D.	Use the SQL MIN () and MAX () Functions to return the smallest and largest value 
-- 1.	Of the LessonID column in the “lesson” table
SELECT *
FROM lessons;
SELECT MIN(LessonID)
FROM lessons;
SELECT MAX(LessonID)
FROM lessons;

-- 2.	Of the membersID column in the “members” table 
SELECT *
FROM Members;
SELECT MIN(MemberID)
FROM Members;
SELECT MAX(MemberID)
FROM Members;

-- E.	Use the SQL COUNT (), AVG () and SUM () Functions for these:
-- 1.	Count the total number of members in the “members” table

SELECT COUNT(*)
FROM Members;

-- 2.	Count the total number of sessions in the” members” table
SELECT COUNT(*) AS sessions
FROM Members;

-- 3.	Find the average session time for all “sessions” in course table --not sure to understand the question. Is it seeions time or lesson time?
-- not working
SELECT AVG(Lessontime) AS Sessions
FROM Course;

-- F.	WILDCARD queries (like operator) 
-- a)	Find all the people from the “members” table whose last name/surname starts with A.
SELECT *
FROM Members;
SELECT *
FROM Members
WHERE Surname LIKE 'a%';

-- b)	Find all the people from the “members” table whose last name/surname ends with A.
SELECT *
FROM Members;
SELECT *
FROM Members
WHERE Surname LIKE '%a';

-- c)	Find all the people from the “members” table that have "ab" in any position in the last name/surname.
SELECT *
FROM Members
WHERE Surname LIKE '%ab%';

-- d)	Find all the people from the “members” table that that have "b" in the second position in their first name.
SELECT *
FROM Members
WHERE Firstname LIKE '_b%';

-- e)	Find all the people from the “members” table whose last name starts with "a" and are at least 3 characters in length:
-- not working
SELECT *
FROM Members
WHERE Surname LIKE 'A__%';

-- f)	Find all the people from the “members” table whose last name starts with "a" and ends with "y"
SELECT *
FROM Members
WHERE Surname LIKE 'A%y';

-- g)	Find all the people from the “members” table whose last name does not starts with "a" and ends with "y"
SELECT *
FROM Members
WHERE Surname NOT LIKE 'A%' AND NOT '%y';


-- G.	What do you understand by LEFT and RIGHT join? Explain with an example.
-- The LEFT JOIN keyword returns all records from the left table (table1), and the matching records from the right table (table2). 
-- The result is 0 records from the right side, if there is no match.
SELECT *
FROM members m LEFT JOIN lessons l ON l.MemberID =  m.MemberID;

-- The RIGHT JOIN keyword returns all records from the right table (table2), and the matching records from the left table (table1). 
-- The result is 0 records from the left side, if there is no match.
SELECT *
FROM course RIGHT JOIN lessons ON course.CourseID = lessons.MemberID;

-- Use mockeroo to generate 20-50 record for each tables
-- Database format SQL


SELECT *
FROM Members
ORDER BY MemberID DESC;

