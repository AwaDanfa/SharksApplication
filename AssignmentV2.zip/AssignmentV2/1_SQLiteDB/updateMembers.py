from connect import *
import readMembers
import time

# subroutine


def update():
    # which field can be used to update record(s) in the Members table?
    "Use the MemberID(unique/primary key)"
    idField = input("Enter the MemberID of the record to be updated: ")
    # field name to be updated
    fieldName = input(
        "Enter field name (Firstname/Surname/Date of Birth/Address/City): ").title()
    # The title() method returns a string where the first character in every word is upper case. Like a header, or a title.
    # If the word contains a number or a symbol, the first letter after that will be converted to upper case.

    newFieldValue = input(f"Enter the value for the {fieldName} field: ")
    # print(newFieldValue)
    # add single quotes to newFieldValue to match data as it is by the python interepreter: Write and run Python code using the online compiler (interpreter). You can use Python Shell like IDLE, and take inputs from the user in our Python compiler.
    newFieldValue = "'" + newFieldValue + "'"
    # print(newFieldValue)

    cursor.execute(
        f"UPDATE Members SET {fieldName} = {newFieldValue} WHERE MemberID = {idField}")
    conn.commit()

    print(f"Record {idField} updated in the Members table")
    time.sleep(3)

    # read from the songs table
    readMembers.read()  # call the read subroutine from the readSongs python file


if __name__ == "__main__":

    update()
