from connect import *
import time

# subroutine


def read():
    cursor.execute("SELECT * FROM Members ORDER BY MemberID ASC")
    # cursor.execute("SELECT * FROM Members WHERE MemberID  = 1")
    # fetchall() method which fetches alll rows selected ffrom the select statement
    row = cursor.fetchall()  # records fetched saved/passed in to the row variable
    for record in row:
        print(record)


# Why use if __name__ == "__main__":?
if __name__ == "__main__":
    read()
