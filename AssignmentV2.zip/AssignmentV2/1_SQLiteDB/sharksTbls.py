from connect import *

cursor.execute("""CREATE TABLE 'Course'(
'CourseID' INT NOT NULL, 
'Level' VARCHAR(50) NOT NULL,
'Sessions' VARCHAR(50) NOT NULL,
'Instructor' VARCHAR(60) NOT NULL,
'StartDate' datetime NOT NULL,
'LessonTime' VARCHAR(60) NOT NULL,
PRIMARY KEY(CourseID))""")


cursor.execute(""" CREATE TABLE 'Members'(
'MemberID' INT NOT NULL, 
'Firstname' VARCHAR(50) NOT NULL,
'Surname' VARCHAR(50) NOT NULL,
'date_of_birth' DATETIME NOT NULL,
'Address' VARCHAR(60) NOT NULL,
'City' VARCHAR(50) NOT NULL,
PRIMARY KEY(MemberID))""")


cursor.execute("""CREATE TABLE 'Lessons'(
'LessonID' INT NOT NULL,
'CourseID' INT NOT NULL,
'MemberID' INT NOT NULL,
PRIMARY KEY(LessonID),
CONSTRAINT CourseID
FOREIGN KEY (CourseID)
REFERENCES course (CourseID)
ON DELETE CASCADE 
ON UPDATE CASCADE,   
CONSTRAINT MemberID
FOREIGN KEY (MemberID)
REFERENCES Members (MemberID)
ON DELETE CASCADE 
ON UPDATE CASCADE) """)
