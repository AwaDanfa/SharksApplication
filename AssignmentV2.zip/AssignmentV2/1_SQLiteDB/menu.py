import readMembers
import addMembers
import updateMembers
import deleteMembers
import searchMembers


# create function
def menuOptions():
    options = 0  # flag variable
    # while 0 not in this list ["1","2","3","4","5","6"] execute the code below
    while options not in ["1", "2", "3", "4", "5", "6", "7"]:
        print("Members Menu Options\nEnter:\n1. To Print.\n2. To Add.\n3. To Update.\n4. To Delete.\n5. Search by ID.\n6. Search by last name.\n7. To Exit.")

        # re-assign the value of the options variable
        # the defaul datatype for input is string
        options = input("Enter an option from the menu choices above: ")
        if options not in ["1", "2", "3", "4", "5", "6", "7"]:
            print(f"{options} is not a valid choice")
    return options


mainProgram = True  # assign mainProgram the value of True which is a boolean data type
while mainProgram:  # same while True
    mainMenu = menuOptions()
    if mainMenu == "1":
        readMembers.read()
    elif mainMenu == "2":
        addMembers.insertMembers()
    elif mainMenu == "3":
        updateMembers.update()
    elif mainMenu == "4":
        deleteMembers.delete()
    elif mainMenu == "5":
        # searchMembers.search()
        searchMembers.searchID()
    elif mainMenu == "6":
        searchMembers.searchbyLastName()
# else must re-assign the value of the mainProgram to False to exit the loop and must be the last option (6)
    else:
        mainProgram = False
        # Quit the the application not to quit the menu
input("Press enter to Quit the application")
