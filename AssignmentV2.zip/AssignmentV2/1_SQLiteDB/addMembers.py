from connect import *
import readMembers
import time

# subroutine


def insertMembers():
    # create an empty list
    members = []
    # ask for user input for the Members table (Firstname, Surname, Address, City)
    memberID = int(input("Enter the member ID: "))
    firstname = input("Enter the member firstname: ")
    surname = input("Enter the member surname: ")
    dateofbirth = input("Enter the member date of birth: ")
    address = input("Enter the member address: ")
    city = input("Enter the member city: ")

    # append data to the list called
    members.append(memberID)
    members.append(firstname)
    members.append(surname)
    members.append(dateofbirth)
    members.append(address)
    members.append(city)

    # Insert data from the Members list into the Members table
    # Use NULL(placehoder) to indicate that no data will be provided for memberID
    # INSERT INTO songs VALUES(NULL, "a", "b","c") the NULL place holder required
    # INSERT INTO Members (Firstname, Surname, Address, City)  VALUES ("a", "b","c") the NULL place holder not required

    # Research what is SQL injection
    # SQL injection is a code injection technique that might destroy your database. SQL injection is one of the most common web hacking techniques.

    cursor.execute("INSERT INTO Members VALUES(?,?,?,?,?,?)", members)
    # commit any pending transaction to the Members table in the database
    conn.commit()

    print(f"Firstname {firstname} inserted in the members table")
    time.sleep(3)  # 3 seconds

    # read from the Members table
    # call the read subroutine from the readMembers python file.
    # readMembers.read()


# read from the Members table
    readMembers.read()  # call the read subroutine from the membersSongs python file


if __name__ == "__main__":
    insertMembers()  # call/invoke the subroutine
""" 


    insertMembers()  # call/invoke the subroutine
"""
