-- SQLite

insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('4', 'Arty', 'Blount', '2022/03/06', '39392 Oak Way', 'Banjar Mambalkajanan');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('39', 'Bartolemo', 'Romke', '2022/04/19', '0 Mosinee Terrace', 'Seixezelo');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('23', 'Kelci', 'Dottrell', '2022/07/30', '793 Basil Parkway', 'Póvoa de Penela');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('28', 'Lacey', 'Lindenblatt', '2022/09/30', '7 Lawn Point', 'Tinawagan');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('38', 'Jacobo', 'McRavey', '2022/06/17', '79 Burrows Terrace', 'Medveđa');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('1', 'Kerwinn', 'Daldry', '2022/10/28', '177 Alpine Court', 'Cergy-Pontoise');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('18', 'Emelen', 'Kleiser', '2023/01/04', '458 Roxbury Hill', 'Emnambithi-Ladysmith');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('35', 'Erika', 'Cleveley', '2022/03/21', '25 Truax Drive', 'Shengping');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('19', 'Winifield', 'Partener', '2022/04/13', '03008 Fordem Trail', 'Shedok');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('42', 'Bernarr', 'Minigo', '2022/06/09', '64745 Lindbergh Pass', 'Huayuan');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('40', 'Teddi', 'Paddison', '2023/01/07', '069 Bay Crossing', 'Zhatay');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('13', 'Evangelina', 'Iggo', '2022/08/29', '8720 Nova Junction', 'Sagua de Tánamo');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('30', 'Rhett', 'Blackwell', '2022/03/12', '177 Scofield Crossing', 'Sanhe');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('3', 'Parker', 'Vedenichev', '2022/08/25', '93482 Donald Terrace', 'Marfino');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('2', 'Thorin', 'Wilcocke', '2022/03/14', '2 Susan Drive', 'Paleran');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('11', 'Palmer', 'Tixier', '2022/07/14', '41272 Blue Bill Park Pass', 'Jargalant');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('41', 'Magdalena', 'Shakeshaft', '2022/07/25', '49 Hagan Alley', 'Tilburg');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('36', 'Merv', 'Proughten', '2022/08/01', '861 Maple Center', 'Nawá');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('24', 'Merry', 'Churchman', '2022/03/22', '3076 Northwestern Trail', 'Ḩakamā');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('21', 'Tris', 'Zellmer', '2022/03/02', '29 Bartillon Terrace', 'Igir-igir');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('32', 'Saw', 'Macoun', '2022/02/13', '37790 Utah Avenue', 'Durham');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('12', 'Humfried', 'Redemile', '2022/10/01', '0 Ridgeway Way', 'Umunede');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('5', 'Bart', 'Whight', '2022/08/30', '7870 Stephen Center', 'Tamiso');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('6', 'Alverta', 'Stickley', '2022/02/27', '13 Havey Center', 'Dois Vizinhos');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('29', 'Pansie', 'Staner', '2022/08/23', '65502 Manley Junction', 'Camiri');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('9', 'Madelena', 'Daveran', '2022/12/25', '8 Blaine Street', 'Malo');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('33', 'Winny', 'Paine', '2022/03/06', '49 Mifflin Point', 'Choca do Mar');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('26', 'Elyssa', 'Leah', '2022/12/06', '1 Autumn Leaf Plaza', 'Guanqian');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('10', 'Keane', 'Chalke', '2022/10/07', '5372 Prairie Rose Alley', 'Kuala Lumpur');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('25', 'Allie', 'Heaps', '2022/05/17', '23 Valley Edge Pass', 'Korsze');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('14', 'Belle', 'Beeton', '2022/12/07', '27 3rd Road', 'Iberia');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('7', 'Franciskus', 'Watkins', '2022/07/28', '069 Lukken Plaza', 'Liozon');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('8', 'Bogey', 'Neicho', '2022/07/11', '1267 Armistice Point', 'Frederiksberg');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('16', 'Boyce', 'Poxon', '2022/07/05', '6241 Anhalt Junction', 'Taipa');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('22', 'Donella', 'Vigers', '2022/02/09', '7278 Florence Center', 'Solidaridad');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('17', 'Rori', 'Winspear', '2022/02/08', '0 Artisan Point', 'Gontar');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('27', 'Donaugh', 'Boutton', '2022/05/01', '4648 Calypso Place', 'Iłowo -Osada');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('20', 'Miltie', 'Challace', '2023/01/10', '1962 3rd Park', 'Aurora');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('37', 'Der', 'Hodgin', '2022/12/27', '8 Maple Terrace', 'Girona');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('15', 'Malanie', 'Lode', '2022/06/23', '4 Sullivan Lane', 'Bouctouche');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('34', 'Jilli', 'Pluvier', '2022/06/08', '48751 Alpine Avenue', 'Luoshan');
insert into Members
  (MemberID, Firstname, Surname, date_of_birth, Address, City)
values
  ('31', 'Jackson', 'Stiller', '2022/09/26', '9503 Raven Way', 'Rincón');