-- SQLite 
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (1, '4', 1);
insert into Lessons
  (LessonID, CourseID, MemberID)
values(2, '27', 2);
insert into Lessons
  (LessonID, CourseID, MemberID)
values(3, '23', 3);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (4, '29', 4);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (5, '16', 5);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (6, '20', 6);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (7, '42', 7);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (8, '5', 8);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (9, '31', 9);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (10, '14', 10);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (11, '37', 11);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (12, '11', 12);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (13, '36', 13);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (14, '33', 14);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (15, '40', 15);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (16, '32', 16);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (17, '21', 17);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (18, '24', 18);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (19, '12', 19);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (20, '30', 20);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (21, '8', 21);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (22, '25', 22);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (23, '3', 23);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (24, '13', 24);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (25, '19', 25);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (26, '41', 26);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (27, '10', 27);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (28, '6', 28);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (29, '2', 29);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (30, '22', 30);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (31, '9', 31);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (32, '17', 32);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (33, '38', 33);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (34, '1', 34);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (35, '18', 35);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (36, '35', 36);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (37, '34', 37);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (38, '28', 38);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (39, '26', 39);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (40, '7', 40);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (41, '15', 41);
insert into Lessons
  (LessonID, CourseID, MemberID)
values
  (42, '39', 42);
