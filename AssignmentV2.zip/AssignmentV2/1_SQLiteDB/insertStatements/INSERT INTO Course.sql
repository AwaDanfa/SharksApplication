-- SQLite
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (1, 'Stage 1', 'Morning', 'Nadine', '2023-03-18', '07:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (2, 'Stage 2', 'Morning', 'Erika', '2022-05-06', '08:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (3, 'Stage 2', 'Morning', 'James', '2022-02-18', '09:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (4, 'Stage 2', 'Morning', 'Saliou', '2022-01-31', '08:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (5, 'Stage 3', 'Morning', 'Erika', '2022-09-19', '07:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (6, 'Stage 2', 'Morning', 'Saliou', '2023-01-31', '09:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (7, 'Stage 3', 'Morning', 'Nadine', '2022-06-14', '08:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (8, 'Stage 3', 'Morning', 'Nadine', '2022-04-16', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (9, 'Stage 4', 'Morning', 'Erika', '2022-12-20', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (10, 'Stage 3', 'Morning', 'Erika', '2022-07-11', '09:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (11, 'Stage 3', 'Morning', 'Saliou', '2022-05-11', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (12, 'Stage 3', 'Morning', 'Erika', '2022-09-10', '08:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (13, 'Stage 1', 'Morning', 'Saliou', '2023-03-10', '08:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (14, 'Stage 1', 'Morning', 'Saliou', '2023-01-08', '08:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (15, 'Stage 4', 'Morning', 'Saliou', '2022-02-27', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (16, 'Stage 4', 'Morning', 'Nadine', '2022-03-14', '07:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (17, 'Stage 2', 'Morning', 'Tash', '2022-11-05', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (18, 'Stage 4', 'Morning', 'Saliou', '2022-12-21', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (19, 'Stage 1', 'Morning', 'James', '2022-03-15', '08:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (20, 'Stage 3', 'Morning', 'Tash', '2022-10-19', '07:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (21, 'Stage 4', 'Morning', 'James', '2022-07-21', '08:00');

insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (22, 'Stage 1', 'Evening', 'Tash', '2022-06-25', '17:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (23, 'Stage 3', 'Evening', 'James', '2023-01-31', '19:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (24, 'Stage 3', 'Evening', 'Tash', '2023-03-29', '18:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (25, 'Stage 4', 'Evening', 'Erika', '2022-11-02', '18:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (26, 'Stage 3', 'Evening', 'Tash', '2022-11-12', '19:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (27, 'Stage 4', 'Evening', 'Nadine', '2022-05-22', '19:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (28, 'Stage 2', 'Evening', 'James', '2022-08-05', '19:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (29, 'Stage 2', 'Evening', 'Erika', '2022-07-12', '19:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (30, 'Stage 3', 'Evening', 'Saliou', '2023-01-04', '19:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (31, 'Stage 2', 'Evening', 'Saliou', '2023-01-05', '17:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (32, 'Stage 1', 'Evening', 'Erika', '2022-12-28', '18:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (33, 'Stage 2', 'Evening', 'Erika', '2023-01-10', '18:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (34, 'Stage 4', 'Evening', 'James', '2022-12-06', '17:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (35, 'Stage 1', 'Evening', 'James', '2022-02-25', '19:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (36, 'Stage 1', 'Evening', 'James', '2023-03-23', '18:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (37, 'Stage 1', 'Evening', 'Tash', '2022-03-27', '18:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (38, 'Stage 1', 'Evening', 'Tash', '2022-08-28', '19:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (39, 'Stage 1', 'Evening', 'Tash', '2022-05-20', '18:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (40, 'Stage 3', 'Evening', 'Nadine', '2022-11-20', '18:00');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (41, 'Stage 2', 'Evening', 'Erika', '2023-03-18', '18:30');
insert into Course
  (CourseID, Level, Sessions, Instructor, startDate, LessonTime)
values
  (42, 'Stage 4', 'Evening', 'Saliou', '2022-02-24', '18:30');
